/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Estudiantes
 */
public class Colas<T>
{
    ListaSE<T> cola;
    public Colas()
    {
        cola=new ListaSE();
    }
    public void encolar(T dato)
    {
        cola.insertarFinal(dato);
    }
    public T decolar()
    {
        T res;
        res=cola.getIni();
        cola.eliminar(1);
        return res;
    }
}
