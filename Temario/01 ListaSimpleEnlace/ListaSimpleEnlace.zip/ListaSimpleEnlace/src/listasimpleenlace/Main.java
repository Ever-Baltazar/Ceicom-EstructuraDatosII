
package listasimpleenlace;

import java.util.Scanner;

public class Main 
{
    public static void main(String[] args) 
    {
        ListaSE<String> nombres = new ListaSE();               
        
        boolean condicionSalir= true;
        
        while(condicionSalir)
        {
            Scanner sc = new Scanner(System.in);
            System.out.println("Ingrese un nombre o el numero cero para terminar");
            String nombre=sc.nextLine();
            if(nombre.equals("0"))
            {
                condicionSalir=false;
            }
            else
            {
                nombres.insertarFinal(nombre);
            }
        }
        nombres.insertarInicio("primerDato");
        nombres.eliminar(3);
        System.out.println("La lista de nombres es: ");
        for(int i=1; i<=nombres.tamaño();i++)
        {
            System.out.println(nombres.obtener(i));
        }
    }
    
}
