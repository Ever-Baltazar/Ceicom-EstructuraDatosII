/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pila;
//OSVALDO
/**
 *
 * @author Estudiantes
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Pilas <Integer> asd = new Pilas();
        asd.push(1);
        asd.push(2);
        asd.push(3);
        asd.push(4);
        System.out.println(asd.pop());
        System.out.println(asd.pop());
        asd.push(5);
        System.out.println(asd.pop());
    }
    
}
