/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pila;

import java.util.Scanner;
import java.util.Stack;
/**
 *
 * @author Estudiantes
 */
public class Pilas<T> 
{
    ListaSE<T> pila;
    public Pilas()
    {
        pila=new ListaSE();
    }
    public void push(T dato)
    {
        pila.insertarFinal(dato);
    }
    public T pop()
    {
        T res;
        res=pila.obtener(pila.tamaño());
        pila.eliminar(pila.tamaño());
        return res;
    }
    public T top()
    {
        return pila.obtener(pila.tamaño());
    }
}
