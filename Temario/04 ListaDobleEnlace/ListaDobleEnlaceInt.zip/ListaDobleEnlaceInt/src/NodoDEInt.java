
public class NodoDEInt
{
    int dato;
    NodoDEInt sig,ant;
    
    public NodoDEInt(int dato)
    {
        this.dato=dato;
        sig=null;
        ant=null;
    }
    public NodoDEInt(int dato,NodoDEInt sig, NodoDEInt ant)
    {
        this.dato=dato;
        this.sig=sig;
        this.ant=ant;
    }  
}
