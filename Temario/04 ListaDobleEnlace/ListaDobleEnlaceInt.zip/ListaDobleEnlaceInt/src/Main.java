
import java.util.Scanner;
import javax.swing.JOptionPane;


public class Main 
{
    public static void main(String [] args)
    {
        ListaDEInt lista=new ListaDEInt();
        
        int numero;
        boolean condicion=true;
        
        while(condicion)
        {
            Scanner sc = new Scanner(System.in);       
            System.out.println("Menu opciones");
            System.out.println("1.- Insertar un numero al inicio\n"
            + "2.- Insertar un numero al final\n"
            + "3.- Mostrar de inicio a fin\n"
            + "4.- Mostrar de fin a inicio\n"
            + "5.- Salir\n");
            int opcion = sc.nextInt();
            if(opcion < 1 || opcion > 5)
            {
                System.out.println("Tiene que escoger una opocion del 1-5");
            }
            else
            {
                if(opcion == 5)
                {
                    condicion=false;
                }
                else
                {
                    if(opcion == 1)
                    {
                        Scanner sc1 = new Scanner(System.in);       
                        System.out.println("Ingrese un numero");
                        numero=sc1.nextInt();
                        lista.insertarInicio(numero);
                    }
                    else
                    {
                        if(opcion == 2)
                        {
                            Scanner sc1 = new Scanner(System.in);       
                            System.out.println("Ingrese un numero");
                            numero=sc1.nextInt();
                            lista.insertarFinal(numero);
                        }
                        else
                        {
                            if(opcion == 3)
                            {
                                lista.mostrarInicioFin();
                            }
                            else
                            {
                                lista.mostrarFinInicio();
                            }                                
                        }
                    }
                }
            }
        }              
    }
}
