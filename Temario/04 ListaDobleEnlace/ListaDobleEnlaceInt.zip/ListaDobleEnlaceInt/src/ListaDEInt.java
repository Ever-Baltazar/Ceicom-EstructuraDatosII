
import javax.swing.JOptionPane;

public class ListaDEInt 
{
    private NodoDEInt inicio, fin;
    
    public ListaDEInt()
    {
        inicio=null;
        fin=null;
    }
    
    public boolean vacia()
    {
        return inicio==null;
    }
    
    public void insertarFinal(int dato)
    {
        if(!vacia())
        {
            fin=new NodoDEInt(dato,null,fin);
            fin.ant.sig=fin;
        }
        else 
        {
            inicio=fin=new NodoDEInt(dato);
        }
    }
    
    public void insertarInicio(int dato)
    {
        if(!vacia())
        {
            inicio=new NodoDEInt(dato,inicio,null);
            inicio.sig.ant=inicio;
        }
        else 
        {
            inicio=fin=new NodoDEInt(dato);
        }
    }
    //mostrar de inicio a fin
    public void mostrarInicioFin()
    {
        if(!vacia())
        {
            String datos="<=>";
            NodoDEInt auxiliar=inicio;
            while(auxiliar!=null)
            {
                datos=datos+ "["+auxiliar.dato+"]<=>";
                auxiliar=auxiliar.sig;
            }
            System.out.println(datos);
        }
    }
    public void mostrarFinInicio()
    {
        if(!vacia())
        {
            String datos="<=>";
            NodoDEInt auxiliar=fin;
            while(auxiliar!=null)
            {
                datos=datos+ "["+auxiliar.dato+"]<=>";
                auxiliar=auxiliar.ant;
            }
            System.out.println(datos);
        }
    }
    public int eliminarInicio()
    {
        int dato=inicio.dato;
        if(inicio==fin)
        {
            inicio=fin=null;
        }
        else
        {
            inicio=inicio.sig;
            inicio.ant=null;
        }
        return dato;
    }
    public int eliminarFinal()
    {
        int dato=fin.dato;
        if(inicio==fin)
        {
            inicio=fin=null;
        }
        else
        {
            fin=fin.ant;
            fin.sig=null;
        }
        return dato;
    }
}
